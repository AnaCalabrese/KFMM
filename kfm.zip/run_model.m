function run_model(model)
    % INPUT: clustering method, can be either 'MoK' or 'MoKhmm';
    % OUTPUT: 2 figures, containing clustering results and mean-tracking.
    
    
    switch model
        case 'MoK2D'            
            MoK2D;
        case 'MoK3D'
            MoK3D;
        case 'MoKhmm2D'
            MoKhmm2D;
        case 'MoKhmm3D'
        MoKhmm3D;
        case 'MoK4n'
        MoK4n;
    end
end